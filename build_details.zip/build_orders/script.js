const STORAGE_BUILDS_KEY = "aomBuildOrder.builds";
const STORAGE_ACTIVE_ID_KEY = "aomBuildOrder.activeBuildId";
const LEGACY_STORAGE_KEY = "aomBuildOrder.active";

const ICONS = {
  food: "images/res_Food.png",
  wood: "images/res_Wood.png",
  gold: "images/gold.png",
  favor: "images/favor.png",
  pop: "images/res_pop.png",
  villager: "images/res_population.png"
};

const DEFAULT_BUILD = {
  id: "amaterasu-opening",
  title: "Amaterasu Opening Build Order",
  subtitle: "Each row shows what changes at that moment, plus the villager distribution after the step.",
  goalLabel: "Goal",
  goalText: "Click Age Up",
  portrait: "images/amaterasu_icon.png",
  goalIcon: "images/score_age_2.png",
  steps: [
    {
      type: "phase",
      label: "Opening"
    },
    {
      time: "0:00",
      food: "4 - Hunt",
      wood: "",
      gold: "",
      favor: "",
      pop: "",
      action: "Queue villagers",
      note: "Send the starting villagers to food immediately.",
      split: {
        food: 4,
        wood: 0,
        gold: 0,
        favor: 0,
        pop: "4/15"
      }
    },
    {
      time: "0:20",
      food: "",
      wood: "1 - Wood",
      gold: "",
      favor: "",
      pop: "",
      action: "Miko builds Shrine",
      note: "This starts favor generation while the economy continues.",
      split: {
        food: 4,
        wood: 1,
        gold: 0,
        favor: 1,
        pop: "5/15"
      }
    },
    {
      time: "1:10",
      food: "",
      wood: "",
      gold: "1 - Gold",
      favor: "",
      pop: "",
      action: "Miko builds Temple",
      note: "Move the next villager to gold so the age-up cost is ready.",
      split: {
        food: 4,
        wood: 1,
        gold: 1,
        favor: 1,
        pop: "6/15"
      }
    },
    {
      time: "1:35",
      food: "Next - Hunt",
      wood: "",
      gold: "",
      favor: "",
      pop: "",
      action: "Maintain villager production",
      note: "The Town Center should stay active the entire opening.",
      split: {
        food: 5,
        wood: 1,
        gold: 1,
        favor: 1,
        pop: "7/15"
      }
    },
    {
      time: "2:00",
      food: "",
      wood: "Next - Wood",
      gold: "",
      favor: "",
      pop: "House",
      action: "Avoid population block",
      note: "Use this row style whenever the population timing matters.",
      split: {
        food: 5,
        wood: 2,
        gold: 1,
        favor: 1,
        pop: "8/25"
      }
    },
    {
      type: "phase",
      label: "Age-Up Window"
    },
    {
      time: "2:30",
      food: "",
      wood: "",
      gold: "",
      favor: "",
      pop: "",
      action: "Click Age Up",
      note: "Exact timing depends on hunt quality, walking distance, and idle time.",
      split: {
        food: 5,
        wood: 2,
        gold: 1,
        favor: 1,
        pop: "8/25"
      }
    }
  ]
};

let buildCollection = [];
let activeBuild = null;

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function createId() {
  if (window.crypto && crypto.randomUUID) {
    return crypto.randomUUID();
  }

  return `build-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function loadBuildCollection() {
  const savedBuilds = localStorage.getItem(STORAGE_BUILDS_KEY);

  if (savedBuilds) {
    try {
      const parsed = JSON.parse(savedBuilds);

      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map(normalizeBuild);
      }
    } catch (error) {
      console.error("Failed to parse saved build collection.", error);
    }
  }

  const legacyBuild = localStorage.getItem(LEGACY_STORAGE_KEY);

  if (legacyBuild) {
    try {
      const parsedLegacyBuild = normalizeBuild(JSON.parse(legacyBuild));
      parsedLegacyBuild.id = parsedLegacyBuild.id || createId();

      localStorage.setItem(STORAGE_BUILDS_KEY, JSON.stringify([parsedLegacyBuild], null, 2));
      localStorage.setItem(STORAGE_ACTIVE_ID_KEY, parsedLegacyBuild.id);

      return [parsedLegacyBuild];
    } catch (error) {
      console.error("Failed to migrate legacy build.", error);
    }
  }

  const defaultBuild = clone(DEFAULT_BUILD);

  localStorage.setItem(STORAGE_BUILDS_KEY, JSON.stringify([defaultBuild], null, 2));
  localStorage.setItem(STORAGE_ACTIVE_ID_KEY, defaultBuild.id);

  return [defaultBuild];
}

function getActiveBuildId(builds) {
  const savedId = localStorage.getItem(STORAGE_ACTIVE_ID_KEY);

  if (savedId && builds.some((build) => build.id === savedId)) {
    return savedId;
  }

  const fallbackId = builds[0]?.id || DEFAULT_BUILD.id;
  localStorage.setItem(STORAGE_ACTIVE_ID_KEY, fallbackId);

  return fallbackId;
}

function setActiveBuildId(buildId) {
  localStorage.setItem(STORAGE_ACTIVE_ID_KEY, buildId);
}

function getActiveBuild(builds) {
  const activeId = getActiveBuildId(builds);
  return builds.find((build) => build.id === activeId) || builds[0] || clone(DEFAULT_BUILD);
}

function normalizeBuild(build) {
  return {
    id: build.id || createId(),
    title: build.title || DEFAULT_BUILD.title,
    subtitle: build.subtitle || DEFAULT_BUILD.subtitle,
    goalLabel: build.goalLabel || DEFAULT_BUILD.goalLabel,
    goalText: build.goalText || DEFAULT_BUILD.goalText,
    portrait: build.portrait || DEFAULT_BUILD.portrait,
    goalIcon: build.goalIcon || DEFAULT_BUILD.goalIcon,
    steps: Array.isArray(build.steps) ? build.steps : clone(DEFAULT_BUILD.steps)
  };
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatArrowText(value) {
  return String(value ?? "")
    .replace(/\s+-\s+/g, " → ")
    .replace(/^\s*-\s*$/g, "→")
    .replace(/^\s*-\s+/g, "→ ")
    .replace(/\s+-\s*$/g, " →");
}

function makeIcon(name, className, altText) {
  return `<img class="${className}" src="${ICONS[name]}" alt="${escapeHtml(altText)}">`;
}

function makeHeader(label, iconName) {
  return `
    <span class="header-label">
      ${makeIcon(iconName, "icon", label)}
      <span>${escapeHtml(label)}</span>
    </span>
  `;
}

function makeResourceCell(value, resourceClass, iconName) {
  if (!value || String(value).trim() === "") {
    return "";
  }

  return `
    <span class="resource-pill ${resourceClass}">
      ${makeIcon(iconName, "mini-icon", resourceClass)}
      <span>${escapeHtml(formatArrowText(value))}</span>
    </span>
  `;
}

function makeActionCell(step) {
  const hasAction = step.action && String(step.action).trim() !== "";
  const hasNote = step.note && String(step.note).trim() !== "";

  if (!hasAction && !hasNote) {
    return "";
  }

  return `
    ${hasAction ? `
      <span class="action-box">
        ${makeIcon("villager", "mini-icon", "Action")}
        <span>${escapeHtml(step.action)}</span>
      </span>
    ` : ""}

    ${hasNote ? `<span class="note">${escapeHtml(step.note)}</span>` : ""}
  `;
}

function makeVillagerDistributionCell(split) {
  if (!split) {
    return "";
  }

  const food = Number.isFinite(Number(split.food)) ? Number(split.food) : 0;
  const wood = Number.isFinite(Number(split.wood)) ? Number(split.wood) : 0;
  const gold = Number.isFinite(Number(split.gold)) ? Number(split.gold) : 0;
  const favor = Number.isFinite(Number(split.favor)) ? Number(split.favor) : 0;

  return `
    <div class="villager-distribution">
      <span class="distribution-part">
        ${makeIcon("food", "mini-icon", "Food")}${food}
      </span>

      <span class="distribution-part">
        ${makeIcon("wood", "mini-icon", "Wood")}${wood}
      </span>

      <span class="distribution-part">
        ${makeIcon("gold", "mini-icon", "Gold")}${gold}
      </span>

      <span class="distribution-part">
        ${makeIcon("favor", "mini-icon", "Favor")}${favor}
      </span>
    </div>
  `;
}

function renderBuildPicker(builds, selectedBuild) {
  const picker = document.getElementById("buildPickerSelect");

  picker.innerHTML = builds.map((build) => {
    const selected = build.id === selectedBuild.id ? "selected" : "";

    return `
      <option value="${escapeHtml(build.id)}" ${selected}>
        ${escapeHtml(build.title)}
      </option>
    `;
  }).join("");

  picker.addEventListener("change", () => {
    const selectedId = picker.value;
    const selected = buildCollection.find((build) => build.id === selectedId);

    if (!selected) {
      return;
    }

    setActiveBuildId(selected.id);
    activeBuild = selected;

    renderBuildInfo(activeBuild);
    renderBuildOrderTable(activeBuild);
  });
}

function renderBuildInfo(build) {
  document.getElementById("buildTitle").textContent = build.title;
  document.getElementById("buildSubtitle").textContent = build.subtitle;

  const portrait = document.getElementById("buildPortrait");
  portrait.src = build.portrait;
  portrait.alt = `${build.title} portrait`;

  const goalIcon = document.getElementById("goalIcon");
  goalIcon.src = build.goalIcon;
  goalIcon.alt = build.goalText || "Goal icon";

  const editBuildLink = document.getElementById("editBuildLink");

  if (editBuildLink) {
    editBuildLink.href = `editor.html?id=${encodeURIComponent(build.id)}`;
  }
}

function renderBuildOrderTable(build) {
  const tableRows = build.steps.map((step) => {
    if (step.type === "phase") {
      return `
        <tr class="phase-row">
          <td colspan="8">
            <span class="phase-label">
              ${makeIcon("pop", "mini-icon", "Phase")}
              ${escapeHtml(step.label || "Phase")}
            </span>
          </td>
        </tr>
      `;
    }

    return `
      <tr>
        <td class="time-cell">${escapeHtml(step.time || "")}</td>

        <td>
          ${makeResourceCell(step.food, "food", "food")}
        </td>

        <td>
          ${makeResourceCell(step.wood, "wood", "wood")}
        </td>

        <td>
          ${makeResourceCell(step.gold, "gold", "gold")}
        </td>

        <td>
          ${makeResourceCell(step.favor, "favor", "favor")}
        </td>

        <td>
          ${makeResourceCell(step.pop, "pop", "pop")}
        </td>

        <td class="action-cell">
          ${makeActionCell(step)}
        </td>

        <td class="distribution-cell">
          ${makeVillagerDistributionCell(step.split)}
        </td>
      </tr>
    `;
  }).join("");

  document.getElementById("buildOrderTable").innerHTML = `
    <div class="table-wrap">
      <table>
        <colgroup>
          <col class="time-col">
          <col class="resource-col">
          <col class="resource-col">
          <col class="resource-col">
          <col class="resource-col">
          <col class="pop-col">
          <col class="action-col">
          <col class="distribution-col">
        </colgroup>

        <thead>
          <tr>
            <th>Time</th>
            <th>${makeHeader("Food", "food")}</th>
            <th>${makeHeader("Wood", "wood")}</th>
            <th>${makeHeader("Gold", "gold")}</th>
            <th>${makeHeader("Favor", "favor")}</th>
            <th>${makeHeader("Pop", "pop")}</th>
            <th>${makeHeader("Action", "villager")}</th>
            <th>Distribution</th>
          </tr>
        </thead>

        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>
  `;
}

function initDisplayPage() {
  buildCollection = loadBuildCollection();
  activeBuild = getActiveBuild(buildCollection);

  renderBuildPicker(buildCollection, activeBuild);
  renderBuildInfo(activeBuild);
  renderBuildOrderTable(activeBuild);
}

initDisplayPage();