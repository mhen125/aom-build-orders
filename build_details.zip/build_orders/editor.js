const STORAGE_BUILDS_KEY = "aomBuildOrder.builds";
const STORAGE_ACTIVE_ID_KEY = "aomBuildOrder.activeBuildId";
const LEGACY_STORAGE_KEY = "aomBuildOrder.active";

const ICONS = {
  food: "images/res_Food.png",
  wood: "images/res_Wood.png",
  gold: "images/gold.png",
  favor: "images/favor.png",
  pop: "images/res_pop.png",
  villager: "images/res_population.png"
};

const DEFAULT_BUILD = {
  id: "amaterasu-opening",
  title: "Amaterasu Opening Build Order",
  subtitle: "Each row shows what changes at that moment, plus the running economy split after the step.",
  goalLabel: "Goal",
  goalText: "Click Age Up",
  portrait: "images/amaterasu_icon.png",
  goalIcon: "images/score_age_2.png",
  steps: [
    {
      type: "phase",
      label: "Opening"
    },
    {
      time: "0:00",
      food: "4 - Hunt",
      wood: "",
      gold: "",
      favor: "",
      pop: "",
      action: "Queue villagers",
      note: "Send the starting villagers to food immediately.",
      split: {
        food: 4,
        wood: 0,
        gold: 0,
        favor: 0,
        pop: "4/15"
      }
    },
    {
      time: "0:20",
      food: "",
      wood: "1 - Wood",
      gold: "",
      favor: "",
      pop: "",
      action: "Miko builds Shrine",
      note: "This starts favor generation while the economy continues.",
      split: {
        food: 4,
        wood: 1,
        gold: 0,
        favor: 1,
        pop: "5/15"
      }
    },
    {
      time: "1:10",
      food: "",
      wood: "",
      gold: "1 - Gold",
      favor: "",
      pop: "",
      action: "Miko builds Temple",
      note: "Move the next villager to gold so the age-up cost is ready.",
      split: {
        food: 4,
        wood: 1,
        gold: 1,
        favor: 1,
        pop: "6/15"
      }
    },
    {
      time: "1:35",
      food: "Next - Hunt",
      wood: "",
      gold: "",
      favor: "",
      pop: "",
      action: "Maintain villager production",
      note: "The Town Center should stay active the entire opening.",
      split: {
        food: 5,
        wood: 1,
        gold: 1,
        favor: 1,
        pop: "7/15"
      }
    },
    {
      time: "2:00",
      food: "",
      wood: "Next - Wood",
      gold: "",
      favor: "",
      pop: "House",
      action: "Avoid population block",
      note: "Use this row style whenever the population timing matters.",
      split: {
        food: 5,
        wood: 2,
        gold: 1,
        favor: 1,
        pop: "8/25"
      }
    },
    {
      type: "phase",
      label: "Age-Up Window"
    },
    {
      time: "2:30",
      food: "",
      wood: "",
      gold: "",
      favor: "",
      pop: "",
      action: "Click Age Up",
      note: "Exact timing depends on hunt quality, walking distance, and idle time.",
      split: {
        food: 5,
        wood: 2,
        gold: 1,
        favor: 1,
        pop: "8/25"
      }
    }
  ]
};

let buildCollection = [];
let editorBuild = null;
let activeComposerMode = "step";
let editingIndex = null;

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function getElement(id) {
  return document.getElementById(id);
}

function createId() {
  if (window.crypto && crypto.randomUUID) {
    return crypto.randomUUID();
  }

  return `build-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getEditorTargetId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

function isCreateNewMode() {
  const params = new URLSearchParams(window.location.search);
  return params.get("new") === "true";
}

function normalizeBuild(build) {
  return {
    id: build.id || createId(),
    title: build.title || DEFAULT_BUILD.title,
    subtitle: build.subtitle || DEFAULT_BUILD.subtitle,
    goalLabel: build.goalLabel || DEFAULT_BUILD.goalLabel,
    goalText: build.goalText || DEFAULT_BUILD.goalText,
    portrait: build.portrait || DEFAULT_BUILD.portrait,
    goalIcon: build.goalIcon || DEFAULT_BUILD.goalIcon,
    steps: Array.isArray(build.steps) ? build.steps : clone(DEFAULT_BUILD.steps)
  };
}

function loadBuildCollection() {
  const savedBuilds = localStorage.getItem(STORAGE_BUILDS_KEY);

  if (savedBuilds) {
    try {
      const parsed = JSON.parse(savedBuilds);

      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map(normalizeBuild);
      }
    } catch (error) {
      console.error("Failed to parse saved build collection.", error);
    }
  }

  const legacyBuild = localStorage.getItem(LEGACY_STORAGE_KEY);

  if (legacyBuild) {
    try {
      const parsedLegacyBuild = normalizeBuild(JSON.parse(legacyBuild));
      parsedLegacyBuild.id = parsedLegacyBuild.id || createId();

      localStorage.setItem(STORAGE_BUILDS_KEY, JSON.stringify([parsedLegacyBuild], null, 2));
      localStorage.setItem(STORAGE_ACTIVE_ID_KEY, parsedLegacyBuild.id);

      return [parsedLegacyBuild];
    } catch (error) {
      console.error("Failed to migrate legacy build.", error);
    }
  }

  const defaultBuild = clone(DEFAULT_BUILD);

  localStorage.setItem(STORAGE_BUILDS_KEY, JSON.stringify([defaultBuild], null, 2));
  localStorage.setItem(STORAGE_ACTIVE_ID_KEY, defaultBuild.id);

  return [defaultBuild];
}

function saveBuildCollection(builds) {
  localStorage.setItem(STORAGE_BUILDS_KEY, JSON.stringify(builds.map(normalizeBuild), null, 2));
}

function getActiveBuildId() {
  const savedId = localStorage.getItem(STORAGE_ACTIVE_ID_KEY);

  if (savedId && buildCollection.some((build) => build.id === savedId)) {
    return savedId;
  }

  const fallbackId = buildCollection[0]?.id || DEFAULT_BUILD.id;
  localStorage.setItem(STORAGE_ACTIVE_ID_KEY, fallbackId);

  return fallbackId;
}

function setActiveBuildId(buildId) {
  localStorage.setItem(STORAGE_ACTIVE_ID_KEY, buildId);
}

function getBuildById(buildId) {
  return buildCollection.find((build) => build.id === buildId) || null;
}

function createNewBuild() {
  return {
    ...clone(DEFAULT_BUILD),
    id: createId(),
    title: "New Build Order",
    subtitle: "Describe the build order here.",
    steps: []
  };
}

function loadInitialEditorBuild() {
  buildCollection = loadBuildCollection();

  if (isCreateNewMode()) {
    const newBuild = createNewBuild();
    buildCollection.push(newBuild);
    saveBuildCollection(buildCollection);
    setActiveBuildId(newBuild.id);
    updateEditorUrl(newBuild.id);
    return normalizeBuild(newBuild);
  }

  const requestedId = getEditorTargetId();

  if (requestedId) {
    const requestedBuild = getBuildById(requestedId);

    if (requestedBuild) {
      setActiveBuildId(requestedBuild.id);
      return normalizeBuild(requestedBuild);
    }
  }

  const activeId = getActiveBuildId();
  const activeBuild = getBuildById(activeId);

  if (activeBuild) {
    updateEditorUrl(activeBuild.id);
    return normalizeBuild(activeBuild);
  }

  return normalizeBuild(buildCollection[0] || clone(DEFAULT_BUILD));
}

function updateEditorUrl(buildId) {
  const newUrl = `${window.location.pathname}?id=${encodeURIComponent(buildId)}`;
  window.history.replaceState({}, "", newUrl);
}

function renderEditorBuildPicker() {
  const picker = getElement("editorBuildPickerSelect");

  picker.innerHTML = buildCollection.map((build) => {
    const selected = editorBuild && build.id === editorBuild.id ? "selected" : "";

    return `
      <option value="${escapeHtml(build.id)}" ${selected}>
        ${escapeHtml(build.title)}
      </option>
    `;
  }).join("");
}

function handleEditorBuildPickerChange() {
  readBuildInfoFields();

  const selectedId = getElement("editorBuildPickerSelect").value;
  const selectedBuild = getBuildById(selectedId);

  if (!selectedBuild) {
    return;
  }

  const savedVersion = getBuildById(editorBuild.id);
  const hasUnsavedChanges = JSON.stringify(normalizeBuild(editorBuild)) !== JSON.stringify(normalizeBuild(savedVersion || {}));

  if (hasUnsavedChanges) {
    const shouldSwitch = confirm("Switch builds without saving your current changes?");

    if (!shouldSwitch) {
      renderEditorBuildPicker();
      return;
    }
  }

  editorBuild = normalizeBuild(selectedBuild);
  setActiveBuildId(editorBuild.id);
  updateEditorUrl(editorBuild.id);

  setBuildInfoFields(editorBuild);
  clearComposer();
  renderRowsList();
  renderEditorBuildPicker();
}

function setBuildInfoFields(build) {
  getElement("titleInput").value = build.title;
  getElement("subtitleInput").value = build.subtitle;
  getElement("goalLabelInput").value = build.goalLabel;
  getElement("goalTextInput").value = build.goalText;
  getElement("portraitInput").value = build.portrait;
  getElement("goalIconInput").value = build.goalIcon;
}

function readBuildInfoFields() {
  editorBuild.title = getElement("titleInput").value.trim() || "Untitled Build Order";
  editorBuild.subtitle = getElement("subtitleInput").value.trim();
  editorBuild.goalLabel = getElement("goalLabelInput").value.trim() || "Goal";
  editorBuild.goalText = getElement("goalTextInput").value.trim() || "Click Age Up";
  editorBuild.portrait = getElement("portraitInput").value.trim() || "images/amaterasu_icon.png";
  editorBuild.goalIcon = getElement("goalIconInput").value.trim() || "images/score_age_2.png";
}

function setComposerMode(mode) {
  activeComposerMode = mode;
  editingIndex = null;

  const isStep = mode === "step";

  getElement("stepModeButton").classList.toggle("active", isStep);
  getElement("milestoneModeButton").classList.toggle("active", !isStep);

  getElement("stepComposer").classList.toggle("hidden", !isStep);
  getElement("milestoneComposer").classList.toggle("hidden", isStep);

  getElement("addRowButton").textContent = isStep ? "Add Step Row" : "Add Milestone Row";

  renderRowsList();
}

function readStepComposer() {
  return {
    time: getElement("rowTimeInput").value.trim(),
    food: getElement("rowFoodInput").value.trim(),
    wood: getElement("rowWoodInput").value.trim(),
    gold: getElement("rowGoldInput").value.trim(),
    favor: getElement("rowFavorInput").value.trim(),
    pop: getElement("rowPopInput").value.trim(),
    action: getElement("rowActionInput").value.trim(),
    note: getElement("rowNoteInput").value.trim(),
    split: {
      food: toNonNegativeNumber(getElement("splitFoodInput").value),
      wood: toNonNegativeNumber(getElement("splitWoodInput").value),
      gold: toNonNegativeNumber(getElement("splitGoldInput").value),
      favor: toNonNegativeNumber(getElement("splitFavorInput").value),
      pop: getElement("splitPopInput").value.trim() || "0/0"
    }
  };
}

function readMilestoneComposer() {
  return {
    type: "phase",
    label: getElement("milestoneTextInput").value.trim() || "New Milestone"
  };
}

function fillStepComposer(step) {
  getElement("rowTimeInput").value = step.time || "";
  getElement("rowFoodInput").value = step.food || "";
  getElement("rowWoodInput").value = step.wood || "";
  getElement("rowGoldInput").value = step.gold || "";
  getElement("rowFavorInput").value = step.favor || "";
  getElement("rowPopInput").value = step.pop || "";
  getElement("rowActionInput").value = step.action || "";
  getElement("rowNoteInput").value = step.note || "";

  const split = step.split || {};

  getElement("splitFoodInput").value = split.food ?? 0;
  getElement("splitWoodInput").value = split.wood ?? 0;
  getElement("splitGoldInput").value = split.gold ?? 0;
  getElement("splitFavorInput").value = split.favor ?? 0;
  getElement("splitPopInput").value = split.pop || "0/0";
}

function fillMilestoneComposer(step) {
  getElement("milestoneTextInput").value = step.label || "";
}

function clearComposer() {
  editingIndex = null;

  getElement("rowTimeInput").value = "";
  getElement("rowFoodInput").value = "";
  getElement("rowWoodInput").value = "";
  getElement("rowGoldInput").value = "";
  getElement("rowFavorInput").value = "";
  getElement("rowPopInput").value = "";
  getElement("rowActionInput").value = "";
  getElement("rowNoteInput").value = "";

  getElement("splitFoodInput").value = 0;
  getElement("splitWoodInput").value = 0;
  getElement("splitGoldInput").value = 0;
  getElement("splitFavorInput").value = 0;
  getElement("splitPopInput").value = "0/0";

  getElement("milestoneTextInput").value = "";

  getElement("addRowButton").textContent = activeComposerMode === "step" ? "Add Step Row" : "Add Milestone Row";

  renderRowsList();
}

function addOrUpdateRow() {
  readBuildInfoFields();

  const newRow = activeComposerMode === "step"
    ? readStepComposer()
    : readMilestoneComposer();

  if (editingIndex !== null && editorBuild.steps[editingIndex]) {
    editorBuild.steps[editingIndex] = newRow;
  } else {
    editorBuild.steps.push(newRow);
  }

  clearComposer();
  renderRowsList();
}

function editRow(index) {
  const step = editorBuild.steps[index];

  if (!step) {
    return;
  }

  editingIndex = index;

  if (step.type === "phase") {
    activeComposerMode = "milestone";

    getElement("stepModeButton").classList.remove("active");
    getElement("milestoneModeButton").classList.add("active");
    getElement("stepComposer").classList.add("hidden");
    getElement("milestoneComposer").classList.remove("hidden");

    fillMilestoneComposer(step);
    getElement("addRowButton").textContent = "Update Milestone Row";
  } else {
    activeComposerMode = "step";

    getElement("stepModeButton").classList.add("active");
    getElement("milestoneModeButton").classList.remove("active");
    getElement("stepComposer").classList.remove("hidden");
    getElement("milestoneComposer").classList.add("hidden");

    fillStepComposer(step);
    getElement("addRowButton").textContent = "Update Step Row";
  }

  renderRowsList();

  document.querySelector(".composer-panel").scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
}

function duplicateRow(index) {
  const step = editorBuild.steps[index];

  if (!step) {
    return;
  }

  editorBuild.steps.splice(index + 1, 0, clone(step));
  renderRowsList();
}

function removeRow(index) {
  if (!editorBuild.steps[index]) {
    return;
  }

  editorBuild.steps.splice(index, 1);

  if (editingIndex === index) {
    clearComposer();
  } else if (editingIndex !== null && editingIndex > index) {
    editingIndex -= 1;
  }

  renderRowsList();
}

function moveRowUp(index) {
  if (index <= 0) {
    return;
  }

  const temp = editorBuild.steps[index - 1];
  editorBuild.steps[index - 1] = editorBuild.steps[index];
  editorBuild.steps[index] = temp;

  if (editingIndex === index) {
    editingIndex = index - 1;
  } else if (editingIndex === index - 1) {
    editingIndex = index;
  }

  renderRowsList();
}

function moveRowDown(index) {
  if (index >= editorBuild.steps.length - 1) {
    return;
  }

  const temp = editorBuild.steps[index + 1];
  editorBuild.steps[index + 1] = editorBuild.steps[index];
  editorBuild.steps[index] = temp;

  if (editingIndex === index) {
    editingIndex = index + 1;
  } else if (editingIndex === index + 1) {
    editingIndex = index;
  }

  renderRowsList();
}

function clearRows() {
  const confirmed = confirm("Clear all rows from the current build? This will not affect the saved display until you click Save Build.");

  if (!confirmed) {
    return;
  }

  editorBuild.steps = [];
  clearComposer();
  renderRowsList();
}

function formatArrowText(value) {
  return String(value ?? "")
    .replace(/\s+-\s+/g, " → ")
    .replace(/^\s*-\s*$/g, "→")
    .replace(/^\s*-\s+/g, "→ ")
    .replace(/\s+-\s*$/g, " →");
}

function renderRowsList() {
  const rowsList = getElement("rowsList");

  if (!editorBuild.steps.length) {
    rowsList.innerHTML = `
      <div class="empty-state">
        No rows yet. Use the composer above to add a build step or milestone line.
      </div>
    `;
    return;
  }

  rowsList.innerHTML = editorBuild.steps.map((step, index) => {
    if (step.type === "phase") {
      return renderMilestoneRow(step, index);
    }

    return renderStepRow(step, index);
  }).join("");

  bindRowButtons();
}

function renderMilestoneRow(step, index) {
  const editingClass = editingIndex === index ? "editing" : "";

  return `
    <article class="editor-row milestone-row">
      <div class="editor-row-number">${index + 1}</div>

      <div class="editor-row-content">
        <div class="milestone-label">
          <img src="${ICONS.pop}" alt="Milestone">
          ${escapeHtml(step.label || "Milestone")}
        </div>
      </div>

      <div class="row-actions">
        <button class="icon-button ${editingClass}" type="button" data-action="edit" data-index="${index}" title="Edit row">✎</button>
        <button class="icon-button" type="button" data-action="duplicate" data-index="${index}" title="Duplicate row">⧉</button>
        <button class="icon-button" type="button" data-action="up" data-index="${index}" title="Move up">↑</button>
        <button class="icon-button" type="button" data-action="down" data-index="${index}" title="Move down">↓</button>
        <button class="icon-button danger" type="button" data-action="delete" data-index="${index}" title="Delete row">×</button>
      </div>
    </article>
  `;
}

function renderStepRow(step, index) {
  const editingClass = editingIndex === index ? "editing" : "";
  const split = step.split || {
    food: 0,
    wood: 0,
    gold: 0,
    favor: 0,
    pop: "0/0"
  };

  return `
    <article class="editor-row">
      <div class="editor-row-number">${index + 1}</div>

      <div class="editor-row-content">
        <div class="editor-row-main">
          ${step.time ? `<span class="editor-time">${escapeHtml(step.time)}</span>` : ""}

          ${makeEditorPill(step.food, "food", "food")}
          ${makeEditorPill(step.wood, "wood", "wood")}
          ${makeEditorPill(step.gold, "gold", "gold")}
          ${makeEditorPill(step.favor, "favor", "favor")}
          ${makeEditorPill(step.pop, "pop", "pop")}

          ${step.action ? `
            <span class="editor-action">
              <img src="${ICONS.villager}" alt="Action">
              ${escapeHtml(step.action)}
            </span>
          ` : ""}
        </div>

        ${step.note ? `<span class="editor-note">${escapeHtml(step.note)}</span>` : ""}

        <div class="editor-split">
          <span><img src="${ICONS.food}" alt="Food">${escapeHtml(split.food ?? 0)}</span>
          <span><img src="${ICONS.wood}" alt="Wood">${escapeHtml(split.wood ?? 0)}</span>
          <span><img src="${ICONS.gold}" alt="Gold">${escapeHtml(split.gold ?? 0)}</span>
          <span><img src="${ICONS.favor}" alt="Favor">${escapeHtml(split.favor ?? 0)}</span>
        </div>
      </div>

      <div class="row-actions">
        <button class="icon-button ${editingClass}" type="button" data-action="edit" data-index="${index}" title="Edit row">✎</button>
        <button class="icon-button" type="button" data-action="duplicate" data-index="${index}" title="Duplicate row">⧉</button>
        <button class="icon-button" type="button" data-action="up" data-index="${index}" title="Move up">↑</button>
        <button class="icon-button" type="button" data-action="down" data-index="${index}" title="Move down">↓</button>
        <button class="icon-button danger" type="button" data-action="delete" data-index="${index}" title="Delete row">×</button>
      </div>
    </article>
  `;
}

function makeEditorPill(value, resourceClass, iconName) {
  if (!value || String(value).trim() === "") {
    return "";
  }

  return `
    <span class="editor-pill ${resourceClass}">
      <img src="${ICONS[iconName]}" alt="${resourceClass}">
      ${escapeHtml(formatArrowText(value))}
    </span>
  `;
}

function bindRowButtons() {
  document.querySelectorAll("[data-action]").forEach((button) => {
    button.addEventListener("click", () => {
      const action = button.dataset.action;
      const index = Number(button.dataset.index);

      if (!Number.isInteger(index)) {
        return;
      }

      if (action === "edit") {
        editRow(index);
      }

      if (action === "duplicate") {
        duplicateRow(index);
      }

      if (action === "up") {
        moveRowUp(index);
      }

      if (action === "down") {
        moveRowDown(index);
      }

      if (action === "delete") {
        removeRow(index);
      }
    });
  });
}

function saveBuild() {
  readBuildInfoFields();

  if (!editorBuild.id) {
    editorBuild.id = createId();
  }

  const normalizedBuild = normalizeBuild(editorBuild);
  const existingIndex = buildCollection.findIndex((build) => build.id === normalizedBuild.id);

  if (existingIndex >= 0) {
    buildCollection[existingIndex] = normalizedBuild;
  } else {
    buildCollection.push(normalizedBuild);
  }

  editorBuild = normalizeBuild(normalizedBuild);

  saveBuildCollection(buildCollection);
  setActiveBuildId(editorBuild.id);
  updateEditorUrl(editorBuild.id);
  renderEditorBuildPicker();

  const button = getElement("saveBuildButton");
  const originalText = button.textContent;

  button.textContent = "Saved";
  button.disabled = true;

  setTimeout(() => {
    button.textContent = originalText;
    button.disabled = false;
  }, 900);
}

function createAndSwitchToNewBuild() {
  readBuildInfoFields();

  const shouldCreate = confirm("Create a new build? Unsaved changes to the current build will be lost unless you save first.");

  if (!shouldCreate) {
    return;
  }

  const newBuild = createNewBuild();

  buildCollection.push(newBuild);
  saveBuildCollection(buildCollection);

  editorBuild = normalizeBuild(newBuild);
  setActiveBuildId(editorBuild.id);
  updateEditorUrl(editorBuild.id);

  setBuildInfoFields(editorBuild);
  clearComposer();
  renderRowsList();
  renderEditorBuildPicker();
}

function exportJson() {
  readBuildInfoFields();
  getElement("jsonBox").value = JSON.stringify(editorBuild, null, 2);
}

function importJson() {
  const rawJson = getElement("jsonBox").value.trim();

  if (!rawJson) {
    alert("Paste build JSON into the box first.");
    return;
  }

  try {
    const importedBuild = normalizeBuild(JSON.parse(rawJson));

    if (!importedBuild.id) {
      importedBuild.id = createId();
    }

    editorBuild = importedBuild;

    const existingIndex = buildCollection.findIndex((build) => build.id === editorBuild.id);

    if (existingIndex >= 0) {
      buildCollection[existingIndex] = editorBuild;
    } else {
      buildCollection.push(editorBuild);
    }

    saveBuildCollection(buildCollection);
    setActiveBuildId(editorBuild.id);
    updateEditorUrl(editorBuild.id);

    setBuildInfoFields(editorBuild);
    clearComposer();
    renderRowsList();
    renderEditorBuildPicker();

    alert("Build JSON imported.");
  } catch (error) {
    alert("Invalid JSON. Check the formatting and try again.");
    console.error(error);
  }
}

function resetBuild() {
  const confirmed = confirm("Reset this build to the default Amaterasu build? This will replace the currently selected build after you save.");

  if (!confirmed) {
    return;
  }

  const currentId = editorBuild.id;

  editorBuild = normalizeBuild({
    ...clone(DEFAULT_BUILD),
    id: currentId
  });

  setBuildInfoFields(editorBuild);
  clearComposer();
  renderRowsList();
}

function toNonNegativeNumber(value) {
  const number = Number(value);

  if (!Number.isFinite(number) || number < 0) {
    return 0;
  }

  return number;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function bindPageEvents() {
  getElement("editorBuildPickerSelect").addEventListener("change", handleEditorBuildPickerChange);

  getElement("stepModeButton").addEventListener("click", () => setComposerMode("step"));
  getElement("milestoneModeButton").addEventListener("click", () => setComposerMode("milestone"));

  getElement("addRowButton").addEventListener("click", addOrUpdateRow);
  getElement("clearComposerButton").addEventListener("click", clearComposer);

  getElement("clearRowsButton").addEventListener("click", clearRows);

  getElement("newBuildButton").addEventListener("click", createAndSwitchToNewBuild);
  getElement("saveBuildButton").addEventListener("click", saveBuild);
  getElement("exportJsonButton").addEventListener("click", exportJson);
  getElement("importJsonButton").addEventListener("click", importJson);
  getElement("resetButton").addEventListener("click", resetBuild);
}

function initEditorPage() {
  editorBuild = loadInitialEditorBuild();

  setBuildInfoFields(editorBuild);
  renderEditorBuildPicker();
  setComposerMode("step");
  bindPageEvents();
  renderRowsList();
}

initEditorPage();